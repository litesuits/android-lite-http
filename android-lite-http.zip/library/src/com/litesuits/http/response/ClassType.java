package com.litesuits.http.response;

/**
 * 
 * @author MaTianyu
 * 2014-3-11上午2:46:22
 */
public abstract class ClassType<T> {}
